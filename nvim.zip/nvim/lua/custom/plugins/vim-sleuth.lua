return { "tpope/vim-sleuth" }
