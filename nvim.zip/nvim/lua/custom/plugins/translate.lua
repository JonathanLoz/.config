return { "uga-rosa/translate.nvim" }
