return {
	"nvzone/typr",
	cmd = "TyprStats",
	dependencies = "nvzone/volt",
	opts = {},
}
